clear; close all;

% Elementy pasywne układu:
R1 = 1*10^3; R2 = 2*10^3; R3 = 10*10^3; C1 = 100*10^-9; C2 = 50*10^-6;

disp("----------------------------------------------------------------------------------");
disp("- Program umożliwiający wizualizacje wykresów Bode'go oraz charakterystyki wy/we -");
disp("----------------------------------------------------------------------------------");

while 1 % realizacja menu
    disp('Wybierz rodzaj filtru:');
    disp('1. Całkujący');
    disp('2. Różniczkujący');
    disp('3. Pasmowoprzepustowy');
    disp('4. Zakończ działanie programu');

    wybor = input('Podaj numer filtru: ');

    switch wybor % wybór nadrzędny
        case 1
            clc;
            while 1 % możliwość powrotu do wyboru I
                disp('Wybrano filtr całkujący');
                wybor2(); % Wywołanie funkcji wyboru modelu
                filtr_wybor = input('Wybierz filtr: ');

                switch filtr_wybor
                    case 1
                        ukladCalkujacy1(R1, C1);
                        break; % Wyjście do głównego menu
                    case 2
                        ukladCalkujacy2(R1, R2, C1);
                        break;
                    case 3
                        ukladCalkujacy3(R1, R2, C1);
                        break;
                    case 4
                        ukladCalkujacy4(R1, R2, R3, C1);
                        break;
                    case 5
                        break; % Powrót do głównego menu
                    otherwise
                        disp("Nieprawidłowy wybór. Spróbuj ponownie.");
                end
            end

        case 2
            clc;
            while 1
                disp('Wybrano filtr różniczkujący');
                wybor2();
                filtr_wybor = input('Wybierz filtr: ');

                switch filtr_wybor
                    case 1
                        ukladRozniczkujacy1(R1, C1);
                        break;
                    case 2
                        ukladRozniczkujacy2(R1, R2, C1);
                        break;
                    case 3
                        %ukladRozniczkujacy3(R1, R2, C1);
                        disp("Realizacja sprzeczna z założeniami MathLab");
                        break;
                    case 4
                        ukladRozniczkujacy4(R1, R2, R3, C1);
                        break;
                    case 5
                        break; % Powrót do głównego menu
                    otherwise
                        disp("Nieprawidłowy wybór. Spróbuj ponownie.");
                end
            end

        case 3
            clc;
            disp('Wybrano filtr pasmowoprzepustowy');
            filtrPP(R1, R2, C1, C2);
            continue; % Powrót do głównego menu

        case 4
            disp('Zakończenie programu.');
            break;

        otherwise
            disp('Nieprawidłowy wybór. Spróbuj ponownie.');
    end
end
