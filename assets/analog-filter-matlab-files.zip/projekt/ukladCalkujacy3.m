function ukladCalkujacy3(R1,R2,C1) 
    %Tworzenie transmitancji:
     a=R2/R1;
     b=C1*R2;
     Licznik=[a];
     Mianownik=[b 1];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
end

