function ukladRozniczkujacy3(R1,R2,C1) 
    %Tworzenie transmitancji:
     a=R2*R1*C1;
     b=R1;
     Licznik=[a R2];
     Mianownik=[b];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
    
end

