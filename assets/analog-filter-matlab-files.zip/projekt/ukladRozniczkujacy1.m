function ukladRozniczkujacy1(R1, C1)
    % Tworzymy obiekt różniczkujący, który jest częścią DSP System Toolbox
    differentiator = dsp.Differentiator;

    % Definiowanie sygnałów wejściowych
    t = 0:0.1:10;   % Czas od 0 do 10 s z krokiem 0.1 s
    we1 = sin(pi * t);  % Pierwszy sygnał wejściowy: sin(pi*t)
    we2 = exp(t);        % Drugi sygnał wejściowy: exp(t)
    we3 = sin(pi * t) .* cos(pi * t + pi/2);  % Trzeci sygnał wejściowy: sin(pi*t)*cos(pi*t+pi/2)

    % Różniczkowanie sygnałów wejściowych (należy transponować - składnia)
    wy1 = differentiator(we1');  % Różniczkowanie sygnału we1
    wy2 = differentiator(we2');  % Różniczkowanie sygnału we2
    wy3 = differentiator(we3');  % Różniczkowanie sygnału we3

    % Wzmocnienie sygnału wyjściowego
    gain = 10^(20/20);  % Wzmocnienie 20 dB
    wy1 = gain * wy1;
    wy2 = gain * wy2;
    wy3 = gain * wy3;

    % Tworzenie wykresów
    figure;
    subplot(3, 2, 1);
    plot(t, we1);
    title('Funkcja wejściowa: sin(\pi t)');
    grid on;

    subplot(3, 2, 2);
    plot(t, wy1);
    title('Funkcja wyjściowa: sin(\pi t) po różniczkowaniu');
    grid on;

    subplot(3, 2, 3);
    plot(t, we2);
    title('Funkcja wejściowa: exp(t)');
    grid on;

    subplot(3, 2, 4);
    plot(t, wy2);
    title('Funkcja wyjściowa: exp(t) po różniczkowaniu');
    grid on;

    subplot(3, 2, 5);
    plot(t, we3);
    title('Funkcja wejściowa: sin(\pi t) * cos(\pi t + \pi/2)');
    grid on;

    subplot(3, 2, 6);
    plot(t, wy3);
    title('Funkcja wyjściowa: sin(\pi t) * cos(\pi t + \pi/2) po różniczkowaniu');
    grid on;

    % Obliczenie odpowiedzi częstotliwościowej dla filtra różniczkującego
    % Dla tego przypadku możemy użyć klasycznej implementacji transmitancji różniczkującej.
    % Transmitancja różniczkująca to H(s) = -sRC

    % Tworzenie klasycznego filtra różniczkującego w formie transmitancji
    s = tf('s');  % Definiowanie zmiennej s
    H = -R1 * C1 * s;  % Transmitancja różniczkująca (H(s) = -sRC)

    % Tworzenie wykresu Bodego
    figure;
    bode(H);  % Wykres Bodego transmitancji
    grid on;
    title('Wykres Bodego dla filtra różniczkującego');
end
