function ukladCalkujacy4(R1,R2,R3,C1) 
    %Tworzenie transmitancji:
     a=C1*R2*R3;
     b=C1*(R2+R3)*R1;
     Licznik=[a R2];
     Mianownik=[b R1];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
end

