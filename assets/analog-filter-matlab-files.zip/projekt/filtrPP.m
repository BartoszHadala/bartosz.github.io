function filtrPP(R1,R2,C1,C2) 
    %Tworzenie transmitancji:
     a=C1*R2;
     b=R2*C2*R1*C1;
     c=(R1*C1)+(R2*C2);
     Licznik=[a 0];
     Mianownik=[b c 1];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
end

