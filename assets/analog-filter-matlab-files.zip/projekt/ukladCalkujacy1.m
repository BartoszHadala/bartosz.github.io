function ukladCalkujacy1(R1,C1) 
    %Tworzenie transmitancji:
     a=1;
     b=R1*C1;
     Licznik=[a];
     Mianownik=[b 0];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
end

