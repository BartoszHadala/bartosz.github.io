function ukladRozniczkujacy2(R1,R2,C1) 
    %Tworzenie transmitancji:
     a=C1*R1;
     b=1;
     Licznik=[a 0];
     Mianownik=[b 1];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
    
end

