function ukladCalkujacy2(R1,R2,C1) 
    %Tworzenie transmitancji:
     a=C1*R2;
     b=C1*R1;
     Licznik=[a 1];
     Mianownik=[b 0];
     H=-tf(Licznik, Mianownik);
    
     cialoFunkcji(H);
end

