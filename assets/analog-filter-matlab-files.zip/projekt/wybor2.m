function  wybor2()
            disp('Wybierz interesujący Cie model:');
            disp('1. Najprostrzy model tylko kondensator');
            disp('2. Połączony rezystor szeregowo do kondensatora');
            disp('3. Połączony rezystor równolegle do kondensatora');
            disp('4. Połączony rezystor szeregowo i równolegle z kondensatorem');
            disp('5. Cofnij');
end
