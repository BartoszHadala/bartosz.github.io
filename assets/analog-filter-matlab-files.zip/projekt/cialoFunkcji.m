function cialoFunkcji(H)

    disp("Generowanie wykresów...");

    % Definiowanie sygnałów wejściowych:
    t_in = 1:0.01:10;
    we1 = sin(pi * t_in);
    we2 = exp(t_in);
    we3 = sin(pi * t_in) .* cos(pi * t_in + pi/2);

    % Tworzenie sygnału wyjściowego
    [wy1, t] = lsim(H, we1, t_in);
    [wy2, t] = lsim(H, we2, t_in);
    [wy3, t] = lsim(H, we3, t_in);

    % Interpolacja wejść do tej samej osi czasu co wyjście, ponieważ metoda
    % lsim może zmieniać próbki czasu, dlatego trzeba dopasować do kroku t
    we1_interp = interp1(t_in, we1, t, 'linear');
    we2_interp = interp1(t_in, we2, t, 'linear');
    we3_interp = interp1(t_in, we3, t, 'linear');

    % Tworzenie wykresów
    figure(1);
    bode(H);
    grid on;

    figure(2);
    step(H);

    figure(3);
    impulse(H);

    % Wyrysowanie wykresów we/wy na jednym wykresie, w tym celu używamy
    % metody yyaxis, aby dopasować dysproporcje funkcji (wzmocnienie)
    figure(4);
    subplot(3, 1, 1);
    yyaxis left;
    xlim([1 10]);
    plot(t, we1_interp, 'b');
    ylabel('Wejście');
    yyaxis right;
    plot(t, wy1, 'r');
    ylabel('Wyjście');
    title('Wejście i wyjście: sin(\pi t)'); 
    grid on;

    subplot(3, 1, 2);
    yyaxis left;
    xlim([1 10]);
    plot(t, we2_interp, 'b');
    ylabel('Wejście');
    yyaxis right;
    plot(t, wy2, 'r');
    ylabel('Wyjście');
    title('Wejście i wyjście: exp(t)');
    grid on;

    subplot(3, 1, 3);
    yyaxis left;
    xlim([1 10]);
    plot(t, we3_interp, 'b');
    ylabel('Wejście');
    yyaxis right;
    plot(t, wy3, 'r');
    ylabel('Wyjście');
    title('Wejście i wyjście: sin(\pi t) * cos(\pi t + \pi/2)');
    grid on;

    clc;

end
